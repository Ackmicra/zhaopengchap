package com.uranus.platform.business.ws.login;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for loginRequest complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name=&quot;loginRequest&quot;&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base=&quot;{http://www.w3.org/2001/XMLSchema}anyType&quot;&gt;
 *       &lt;sequence&gt;
 *         &lt;element name=&quot;brNo&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;content&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;reqDate&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;reqSerial&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;reqTime&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *         &lt;element name=&quot;txCode&quot; type=&quot;{http://www.w3.org/2001/XMLSchema}string&quot; minOccurs=&quot;0&quot;/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "loginRequest", propOrder = { "brNo", "content", "reqDate",
		"reqSerial", "reqTime", "txCode" })
public class LoginRequest {

	protected String brNo;
	protected String content;
	protected String reqDate;
	protected String reqSerial;
	protected String reqTime;
	protected String txCode;

	/**
	 * Gets the value of the brNo property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBrNo() {
		return brNo;
	}

	/**
	 * Sets the value of the brNo property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBrNo(String value) {
		this.brNo = value;
	}

	/**
	 * Gets the value of the content property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getContent() {
		return content;
	}

	/**
	 * Sets the value of the content property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setContent(String value) {
		this.content = value;
	}

	/**
	 * Gets the value of the reqDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getReqDate() {
		return reqDate;
	}

	/**
	 * Sets the value of the reqDate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReqDate(String value) {
		this.reqDate = value;
	}

	/**
	 * Gets the value of the reqSerial property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getReqSerial() {
		return reqSerial;
	}

	/**
	 * Sets the value of the reqSerial property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReqSerial(String value) {
		this.reqSerial = value;
	}

	/**
	 * Gets the value of the reqTime property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getReqTime() {
		return reqTime;
	}

	/**
	 * Sets the value of the reqTime property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReqTime(String value) {
		this.reqTime = value;
	}

	/**
	 * Gets the value of the txCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTxCode() {
		return txCode;
	}

	/**
	 * Sets the value of the txCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setTxCode(String value) {
		this.txCode = value;
	}

}
