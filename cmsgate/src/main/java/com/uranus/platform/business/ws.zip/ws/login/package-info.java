@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.inf.creditapp.app/")
package com.uranus.platform.business.ws.login;

